package com.example.appmusic

data class MyData(
    val `data`: List<Data>,
    val next: String,
    val total: Int
)