package com.example.appmusic

import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Headers
import retrofit2.http.Query

interface ApiInterface {

    @Headers("x-rapidapi-key:3628e1c030mshe42ce8bfdf95325p1fb3c9jsn249105dd150b" ,
                "x-rapidapi-host:deezerdevs-deezer.p.rapidapi.com")
    @GET("search")
    fun getData(@Query("q") query: String) : Call<MyData>
}